const express = require('express');
const path = require('path');

const app = express();
const PORT = 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));

app.use(express.urlencoded({ extended: true }));

const menu = [
  { id: 1, name: 'Cheese Pizza', price: 8.99 },
  { id: 2, name: 'Pepperoni Pizza', price: 9.99 },
  { id: 3, name: 'Veggie Pizza', price: 10.49 },
  { id: 99, name: 'Custom Pizza', price: 0.00 }   // base price for custom pizza
];

const TOPPINGS = [
  { id: 'pepperoni', name: 'Pepperoni', price: 1.5 },
  { id: 'sausage', name: 'Italian Sausage', price: 1.5 },
  { id: 'bacon', name: 'Bacon', price: 1.5 },
  { id: 'mushrooms', name: 'Mushrooms', price: 1.0 },
  { id: 'onions', name: 'Onions', price: 0.75 },
  { id: 'peppers', name: 'Green Peppers', price: 0.75 },
  { id: 'olives', name: 'Black Olives', price: 1.0 },
  { id: 'extra_cheese', name: 'Extra Cheese', price: 1.5 }
];

let orders = [];

app.get('/', (req, res) => {
  res.render('index', { menu });
});

app.get('/order', (req, res) => {
  res.render('order', { menu, toppings: TOPPINGS });
});

app.post('/order', (req, res) => {
  const { customerName, pizzaId, quantity } = req.body;

  const item = menu.find(m => m.id === parseInt(pizzaId, 10));
  if (!item) {
    return res.status(400).send('Invalid pizza selection');
  }

  const qty = parseInt(quantity, 10) || 1;

  const baseTotal = qty * item.price;

  let selectedToppings = req.body.toppings || [];

  if (!Array.isArray(selectedToppings)) {
    selectedToppings = [selectedToppings];
  }

  const toppingDetails = TOPPINGS.filter(t => selectedToppings.includes(t.id));

  const toppingsTotal = toppingDetails.reduce((sum, t) => sum + t.price, 0) * qty;

  const grandTotal = baseTotal + toppingsTotal;

  const newOrder = {
    id: orders.length + 1,
    customerName,
    itemName: item.name,
    quantity: qty,
    basePrice: item.price.toFixed(2),
    toppings: toppingDetails.map(t => t.name),
    toppingsCost: toppingsTotal.toFixed(2),
    total: grandTotal.toFixed(2)
  };

  orders.push(newOrder);

  res.render('order-confirmation', { order: newOrder });
});

app.get('/orders', (req, res) => {
  res.render('orders', { orders });
});

app.listen(PORT, function () {
  console.log('Pizza app running at http://localhost:' + PORT);
});
