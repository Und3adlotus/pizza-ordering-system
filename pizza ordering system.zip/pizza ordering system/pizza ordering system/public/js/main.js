// public/js/main.js

console.log('Cowabunga Pizza client script loaded.');

// Later: hook up Add to Cart buttons to /api/cart/items
