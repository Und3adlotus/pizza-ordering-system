const express = require('express');
const path = require('path');

const app = express();
const PORT = 3000;

// View engine setup (EJS for templating)
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Serve static files (CSS, images, client JS)
app.use(express.static(path.join(__dirname, 'public')));

// Parse form data
app.use(express.urlencoded({ extended: true }));

// Simple in-memory "menu" and "orders" (your own data)
const menu = [
  { id: 1, name: 'Cheese Pizza', price: 8.99 },
  { id: 2, name: 'Pepperoni Pizza', price: 9.99 },
  { id: 3, name: 'Veggie Pizza', price: 10.49 },
];

let orders = [];

// Home page
app.get('/', (req, res) => {
  res.render('index', { menu });
});

// Show order form
app.get('/order', (req, res) => {
  res.render('order', { menu });
});

// Handle order submission
app.post('/order', (req, res) => {
  const { customerName, pizzaId, quantity } = req.body;

  const item = menu.find(m => m.id === parseInt(pizzaId, 10));
  if (!item) {
    return res.status(400).send('Invalid pizza selection');
  }

  const qty = parseInt(quantity, 10) || 1;
  const total = qty * item.price;

  const newOrder = {
    id: orders.length + 1,
    customerName,
    itemName: item.name,
    quantity: qty,
    total: total.toFixed(2)
  };

  orders.push(newOrder);

  res.render('order-confirmation', { order: newOrder });
});

// View all orders (basic admin page)
app.get('/orders', (req, res) => {
  res.render('orders', { orders });
});

app.listen(PORT, () => {
  console.log(`Pizza app running at http://localhost:${PORT}`);
});
